datablock SFXProfile(BellTowerSound)
{
   local = 1;
   filename = "yolauncher/modpack/mods/LiFx/BelltowerFix/art/sound/belltower/BellTowerSound.ogg";
   //description = AudioObjectsCloseLoop3D;
   description = AudioDefault3D;
};
datablock SFXProfile(ChurchBell)
{
   local = 1;
   filename = "yolauncher/modpack/mods/LiFx/BelltowerFix/art/sound/belltower/churchbell.ogg";
   //description = AudioObjectsCloseLoop3D;
   description = AudioDefault3D;
};

